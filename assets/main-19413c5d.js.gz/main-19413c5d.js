
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://fantastic-admin.gitee.io
 * Github https://fantastic-admin.github.io
 */
  
import{d as g,X as h,Y as b,e as k,o as n,f as i,g as S,w as d,h as f,L as s,O as m,t as B,i as v,W as y,Z as C,_ as N,q as V}from"./index-b8c7047d.js";import j from"./sub-fddd548f.js";const w={class:"sidebar-item"},F={class:"item"},L={class:"title"},O=g({name:"SidebarItem",__name:"main",props:{item:{}},setup(T){const o=h(b,Function,!0);return(e,q)=>{var c,r;const l=N,I=k("el-sub-menu");return n(),i("div",w,[S(I,{title:v(o)((c=e.item.meta)==null?void 0:c.i18n,(r=e.item.meta)==null?void 0:r.title),index:JSON.stringify(e.item),"popper-class":"fa-popup-menu"},{title:d(()=>{var t,a,p,_,u;return[f("div",F,[(t=e.item.meta)!=null&&t.icon?(n(),s(l,{key:0,name:e.item.meta.icon,class:"title-icon unactive",async:""},null,8,["name"])):m("",!0),(a=e.item.meta)!=null&&a.activeIcon||(p=e.item.meta)!=null&&p.icon?(n(),s(l,{key:1,name:e.item.meta.activeIcon||e.item.meta.icon,class:"title-icon active",async:""},null,8,["name"])):m("",!0),f("span",L,B(v(o)((_=e.item.meta)==null?void 0:_.i18n,(u=e.item.meta)==null?void 0:u.title)),1)])]}),default:d(()=>[(n(!0),i(y,null,C(e.item.children,t=>{var a;return n(),i(y,null,[((a=t.meta)==null?void 0:a.sidebar)!==!1?(n(),s(j,{key:t.path,item:t},null,8,["item"])):m("",!0)],64)}),256))]),_:1},8,["title","index"])])}}});const J=V(O,[["__scopeId","data-v-037792e7"]]);export{J as default};
