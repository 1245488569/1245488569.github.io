
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://fantastic-admin.gitee.io
 * Github https://fantastic-admin.github.io
 */
  
import{d as p,u as _,y as g,i as e,o as s,f as o,g as h,t as c,O as i,W as y,_ as d,p as u,k as m,h as l,q as f}from"./index-b8c7047d.js";const k=n=>(u("data-v-c78ce354"),n=n(),m(),n),b={key:0,class:"copyright"},S=k(()=>l("span",null,"Copyright",-1)),v={key:0},x=["href"],C={key:1},I={key:2,href:"https://beian.miit.gov.cn/",target:"_blank",rel:"noopener"},w=p({name:"Copyright",__name:"index",setup(n){const a=_(),t=g();return(B,N)=>{const r=d;return e(a).meta.copyright??e(t).settings.copyright.enable?(s(),o("footer",b,[S,h(r,{name:"ri:copyright-line",size:18}),e(t).settings.copyright.dates?(s(),o("span",v,c(e(t).settings.copyright.dates),1)):i("",!0),e(t).settings.copyright.company?(s(),o(y,{key:1},[e(t).settings.copyright.website?(s(),o("a",{key:0,href:e(t).settings.copyright.website,target:"_blank",rel:"noopener"},c(e(t).settings.copyright.company),9,x)):(s(),o("span",C,c(e(t).settings.copyright.company),1))],64)):i("",!0),e(t).settings.copyright.beian?(s(),o("a",I,c(e(t).settings.copyright.beian),1)):i("",!0)])):i("",!0)}}});const q=f(w,[["__scopeId","data-v-c78ce354"]]);export{q as default};
